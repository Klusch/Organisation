$wnd.com_vaadin_demo_dashboard_DashboardWidgetSet.runAsyncCallback3('Shb(1,null,{});_.gC=function X(){return this.cZ};r8d(Zh)(3);\n//# sourceURL=com.vaadin.demo.dashboard.DashboardWidgetSet-3.js\n')
